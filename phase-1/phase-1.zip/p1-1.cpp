//1. cube
#include<iostream>

using namespace std;

main()
{
	int a;
	
	cout<<"Enter A :- ";
	cin>>a;
	
	cout<<"Cube of "<<a<<" is :- "<<a*a*a;
}
