//19. multiplication tabal.

#include<iostream>

using namespace std;

main()
{
	int n;
	
	cout<<"Enter N :- ";
	cin>>n;
	
	int i;
	
	for(i=1;i<=10;i++)
	{
		cout<<""<<n<<" x "<<i<<" =  "<<n*i<<endl;
	}
}
