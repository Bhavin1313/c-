//2. multiplication of any three number.

#include<iostream>

using namespace std;

main()
{
	int a,b,c;
	
	cout<<"Enter A :- ";
	cin>>a;
	cout<<"Enter B :- ";
	cin>>b;
	cout<<"Enter C :- ";
	cin>>c;
	
	cout<<"Multiplication of "<<a<<","<<b<<" and "<<c<<" is :- "<<a*b*c;
}
