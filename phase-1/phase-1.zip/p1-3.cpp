//3. quotient and remainder.

#include<iostream>

using namespace std;

main()
{
	int a,b;
	
	cout<<"Enter A :- ";
	cin>>a;
	cout<<"Enter B :- ";
	cin>>b;
	
	cout<<"Quotient of "<<a<<" and "<<b<<" is :- "<<a/b<<endl;
	cout<<"Remainder of "<<a<<" and "<<b<<" is :- "<<a%b;
}
